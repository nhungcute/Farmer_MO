﻿# 16 — ASSET & ANIMATION PRODUCTION PIPELINE

Tài liệu này mô tả **cách tạo animation**, không chỉ cách load animation ở runtime. Một animation chỉ được coi là hoàn thành khi có source frame, manifest, atlas, preview và mapping vào renderer.

## 1. Nguyên tắc sản xuất

- Không dùng một ảnh farm khổng lồ làm background gameplay.
- Farm được tách thành terrain, building, crop, animal, pond và effects.
- Mọi frame của một animation phải có cùng canvas size, pivot và hướng sáng.
- Runtime không tự cắt ảnh hoặc tự đoán anchor.
- Asset source phải có license hoặc được tạo nội bộ; không commit asset không rõ nguồn.
- Bản runtime là output có thể tái tạo từ source, không chỉnh tay trực tiếp trong atlas.
- Animation state chỉ mô tả hiển thị. Server vẫn lưu timer/state economy, không lưu frame hiện tại.

## 2. Style lock trước khi tạo frame

Trước khi vẽ asset đầu tiên, chốt một style sheet gồm:

```text
Perspective: isometric 2.5D
Tile logical size: 128x64
Light direction: top-left
Outline: consistent dark-green/brown outline
Shadow: soft, same direction and opacity
Palette: cream, wood, grass green, water blue, gold
Camera scale: one world tile = one logical tile
```

Mỗi asset mới phải được so với style sheet trước khi đưa vào atlas. Không nhận asset đúng hình nhưng sai perspective, scale hoặc hướng sáng.

## 3. Folder source

```text
assets-src/
├── style/
│   ├── style-sheet.md
│   ├── palette.aseprite
│   └── reference-board/
├── terrain/
├── buildings/
├── crops/
├── animals/
├── ponds/
├── decor/
├── effects/
├── ui/
└── manifests/
    ├── buildings.json
    ├── crops.json
    ├── animals.json
    └── effects.json
```

Output đã pack:

```text
apps/web/public/assets/
├── atlases/
│   ├── farm_common.webp
│   ├── farm_common.json
│   ├── crops.webp
│   ├── crops.json
│   ├── chicken.webp
│   ├── chicken.json
│   └── effects.webp
└── manifests/
    └── animation-manifest.json
```

## 4. Công cụ tạo source

Source có thể được tạo bằng một trong các công cụ sau, miễn output tuân thủ cùng contract:

- Krita hoặc Aseprite cho frame-by-frame raster.
- Blender orthographic camera cho building/pond render từ cùng một góc isometric.
- SVG/Illustrator cho icon UI tĩnh nếu cần.

Quy tắc bắt buộc:

- Master source giữ layer hoặc frame gốc, không chỉ giữ file WebP đã flatten.
- Export intermediate là PNG RGBA để giữ alpha và kiểm tra frame.
- Runtime format là WebP/PNG theo atlas pipeline.
- Không đưa file PSD/ORA/BLEND nặng vào web bundle.
- Ghi tool, phiên bản, license và người tạo trong `asset-manifest`.

## 5. Canvas, scale và pivot

- World tile logical: `128x64`.
- Asset source tạo ở scale 2x logical nếu là raster: một tile tương đương `256x128` source pixels.
- Runtime atlas giữ metadata scale để renderer không tự đoán.
- Tất cả frame trong cùng animation có cùng kích thước canvas.
- Vùng trong suốt phải giữ nguyên để pivot không nhảy giữa frame.
- Anchor lưu normalized `0..1` và được kiểm tra trên debug grid.

Ví dụ:

```json
{
  "anchor": { "x": 0.5, "y": 0.86 },
  "footprint": { "w": 3, "h": 2 },
  "sourceScale": 2
}
```

## 6. Asset animation bắt buộc của MVP

MVP dùng `Pixi AnimatedSprite + JSON atlas`. Spine không nằm trong MVP; chỉ xem xét ở phase future khi có nhu cầu rig phức tạp và license riêng.

### Terrain

| Asset | Loại | Số frame | FPS | Loop |
|---|---|---:|---:|---|
| `terrain_grass_tile` | Static | 1 | — | — |
| `terrain_grass_variant_01..04` | Static variants | 1 mỗi variant | — | — |

### Buildings

| Asset | Loại | Số frame | FPS | Loop |
|---|---|---:|---:|---|
| `building_farmhouse_lv1` | Static | 1 | — | — |
| `building_warehouse_lv1` | Static | 1 | — | — |
| `building_chicken_coop_lv1` | Static | 1 | — | — |
| `pond_small_lv1_base` | Static | 1 | — | — |

### Pond

| Animation | Số frame | FPS | Loop | Ghi chú |
|---|---:|---:|---|---|
| `pond_water` | 8 | 12 | Yes | Water surface |
| `pond_ripple` | 6 | 10 | Yes | Nhẹ, không fluid simulation |
| `pond_sparkle` | 4 | 8 | Yes | Có thể tắt ở Low quality |

Không tạo fish shadow hoặc fishing animation trong MVP.

### Crops

Mỗi crop có 5 texture tĩnh, không cần AnimatedSprite:

```text
seed
stage_1
stage_2
stage_3
ready
```

Danh sách bắt buộc:

```text
rice_seed, rice_stage_1, rice_stage_2, rice_stage_3, rice_ready
carrot_seed, carrot_stage_1, carrot_stage_2, carrot_stage_3, carrot_ready
corn_seed, corn_stage_1, corn_stage_2, corn_stage_3, corn_ready
tomato_seed, tomato_stage_1, tomato_stage_2, tomato_stage_3, tomato_ready
```

`ready` có thể dùng `crop_ready_glow` chung:

```text
frames: 4
fps: 8
loop: yes
```

### Chicken

| State | Số frame | FPS | Loop |
|---|---:|---:|---|
| `idle` | 4 | 6 | Yes |
| `walk` | 6 | 8 | Yes |
| `eat` | 5 | 10 | No, giữ frame cuối |
| `happy` | 4 | 8 | No |
| `sleep` | 2 | 3 | Yes |
| `product_ready` | 2 | 2 | Yes |

Chicken MVP có 4 hướng isometric cố định:

```text
NE, SE, SW, NW
```

Mỗi state có frame set riêng theo hướng. Nếu direction chưa có asset, dùng `idle` cùng hướng làm fallback. Chicken movement chỉ local trong coop bounds. Không đồng bộ pixel position lên server.

### Effects

| Effect | Số frame | FPS | Loop |
|---|---:|---:|---|
| `fx_harvest` | 6 | 12 | No |
| `fx_build_success` | 6 | 12 | No |
| `fx_coin_gain` | 8 | 12 | No |
| `fx_egg_collect` | 6 | 12 | No |

Thêm các asset/UI state tối thiểu:

```text
fx_plant: 4 frames @ 12fps, one-shot
build_ghost_valid: 1 static client tint
build_ghost_invalid: 1 static client tint
item icons: coin, diamond, rice, carrot, corn, tomato, chicken_feed, egg, order
rotate overlay, loading, success toast, error toast
```

UI button animation dùng CSS/GSAP; không đưa mọi UI tween vào texture atlas.
UI transition mặc định 150–220ms và phải tôn trọng `prefers-reduced-motion`.

## 7. Naming contract

Tên file phải theo format lowercase, không dấu, zero-padded frame index:

```text
building_farmhouse_lv1.webp
building_warehouse_lv1.webp
building_chicken_coop_lv1.webp
pond_small_lv1_base.webp
pond_small_lv1_water_00.webp
pond_small_lv1_water_01.webp
crop_rice_seed.webp
crop_rice_stage_01.webp
crop_rice_ready.webp
animal_chicken_idle_00.webp
animal_chicken_walk_05.webp
animal_chicken_eat_04.webp
fx_harvest_05.webp
```

Không dùng tên phụ thuộc UI tiếng Việt. UI label nằm trong localization, asset ID dùng tiếng Anh ổn định.

## 8. Animation manifest

Mỗi animation phải có manifest machine-readable:

```json
{
  "id": "animal_chicken",
  "atlas": "chicken",
  "directions": ["NE", "SE", "SW", "NW"],
  "sourceScale": 2,
  "anchor": { "x": 0.5, "y": 0.9 },
  "animations": {
    "IDLE": {
      "direction": "SE",
      "frames": [
        "animal_chicken_idle_00",
        "animal_chicken_idle_01",
        "animal_chicken_idle_02",
        "animal_chicken_idle_03"
      ],
      "fps": 6,
      "loop": true,
      "holdLast": false
    },
    "EAT": {
      "direction": "SE",
      "frames": [
        "animal_chicken_eat_00",
        "animal_chicken_eat_01",
        "animal_chicken_eat_02",
        "animal_chicken_eat_03",
        "animal_chicken_eat_04"
      ],
      "fps": 10,
      "loop": false,
      "holdLast": true
    }
  }
}
```

Manifest phải kiểm tra được:

- Frame tồn tại trong atlas.
- Không trùng frame ID.
- FPS > 0.
- Animation state có mapping runtime.
- Anchor nằm trong `0..1`.
- Số frame tối thiểu đúng theo asset spec.

Manifest production phải có thêm:

```text
renderOffset
fallbackFrame
sourceFile
license
```

Nếu atlas packer trim transparent pixels, frame metadata phải giữ `originalSize`, `sourceSize` và `pivot` để anchor không bị thay đổi.

## 9. Quy trình tạo animation

### Bước 1 — Tạo style/reference

- Chốt style sheet, palette, light direction và tile scale.
- Ghi nguồn tham chiếu và license.
- Tạo một asset mẫu: `terrain_grass_tile`, `farmhouse`, `chicken_idle`.
- Review mẫu trước khi tạo toàn bộ asset.

### Bước 2 — Tạo source frame

- Tạo cùng canvas size cho toàn bộ state.
- Đặt pivot/anchor ở chân entity.
- Giữ cùng hướng sáng và camera.
- Không crop từng frame theo bounding box riêng.
- Đặt frame index từ `00`.

### Bước 3 — Export intermediate

- Export PNG RGBA từng frame.
- Kiểm tra alpha, kích thước, màu và đường viền.
- Chạy tên file validator.
- Đưa source và metadata vào `assets-src/`, không đưa PNG source vào web bundle.

### Bước 4 — Tạo manifest

- Khai báo state, frame order, FPS, loop, anchor và atlas group.
- Không khai báo frame không tồn tại.
- Không để renderer tự suy luận animation từ tên file.

### Bước 5 — Pack atlas

Dùng một wrapper duy nhất, ví dụ:

```text
pnpm assets:validate
pnpm assets:pack
pnpm assets:preview
```

Wrapper phải tạo JSON atlas tương thích PixiJS 8 và giữ frame name nguyên vẹn. Không pack thủ công từng atlas bằng nhiều quy tắc khác nhau.

Atlas dùng padding/extrude 2–4 pixels để tránh texture bleeding. Runtime atlas không dùng AVIF; dùng WebP RGBA và PNG fallback khi browser target không hỗ trợ alpha ổn định.

Atlas group MVP:

```text
farm_common: terrain + farmhouse + warehouse + coop + pond base
crops: toàn bộ crop stage + crop_ready_glow
chicken: toàn bộ chicken states
effects: harvest/build/coin/egg/plant effects
```

Giới hạn atlas mobile MVP là `2048x2048`; vượt giới hạn phải chia group, không tự tăng lên một atlas khổng lồ.

### Bước 6 — Preview sheet

`pnpm assets:preview` phải tạo preview HTML hoặc contact sheet để kiểm tra:

- Frame order.
- Loop seam.
- Pivot.
- Scale giữa các state.
- Missing frame.
- Flicker hoặc texture bleeding.

### Bước 7 — Tích hợp runtime

- `AnimationRegistry` đọc manifest.
- `EntityViewFactory` tạo `AnimatedSprite` từ state.
- Renderer dùng Pixi shared ticker, không tạo `requestAnimationFrame` cho từng entity.
- API không được gọi từ AnimationView.
- Khi state server đổi, view chuyển animation state tương ứng.

Loader contract:

```text
AssetRegistry.loadManifest()
AssetRegistry.loadAtlas(group)
AnimationRegistry.get(id, state, direction)
AnimationRegistry.fallback(id, state, direction)
```

Nếu chưa có production art ở G1/G2, dùng placeholder cùng manifest và anchor để kiểm tra renderer. Placeholder phải được đánh dấu `placeholder: true` và không được coi là art final.

Mapping canonical:

```text
Crop READY        → crop_ready + crop_ready_glow
Pond building    → water + ripple + sparkle
Chicken IDLE     → IDLE
Chicken WALK     → WALK
Chicken feeding  → EAT
Chicken product  → PRODUCT_READY
Harvest success  → fx_harvest
Build success    → fx_build_success
```

### Bước 8 — QA và sign-off

Asset owner kiểm tra style/pivot. Developer kiểm tra manifest/runtime. QA kiểm tra mobile/FPS/memory. Chỉ sau ba bước này asset mới được đánh dấu `approved`.

## 10. Texture atlas và export

Ưu tiên:

- WebP RGBA cho sprite runtime.
- PNG chỉ khi WebP alpha hoặc browser target gặp vấn đề.
- JSON atlas tương thích PixiJS 8.
- Atlas tối đa 2048x2048 cho group mobile MVP; chia group nếu vượt.
- Không để một atlas chứa toàn bộ future content.
- Tên atlas có content version hoặc asset hash để service worker không giữ asset cũ.

Canvas source chuẩn cho MVP:

```text
crop frame:    128x128 logical canvas, 256x256 source pixels ở scale 2
chicken frame: 128x128 logical canvas, 256x256 source pixels ở scale 2
pond frame:    256x192 logical canvas, 512x384 source pixels ở scale 2
building:      tối đa 512x384 logical canvas, tùy footprint
```

Các frame trong cùng clip luôn có cùng canvas size và base anchor; không crop từng frame làm entity rung.

## 11. Runtime animation budget

Không để mọi object chạy 60fps.

```text
Water: 12 fps
Pond ripple: 10 fps
Animal: 6–10 fps
Effects: 12 fps
UI tween: 60fps nhưng ngắn
```

Camera xa:

- Tắt sparkle nhỏ.
- Giảm animal update.
- Dùng water static variant nếu frame-time vượt budget.
- Không tắt animation state economy-critical nếu nó làm người chơi hiểu sai; `PRODUCT_READY` phải vẫn có tín hiệu tĩnh.

## 12. Missing asset và fallback

Nếu atlas hoặc frame bị thiếu:

- Log một structured warning có asset ID.
- Dùng placeholder magenta/debug trong development.
- Dùng static fallback cùng silhouette ở production demo.
- Không crash toàn bộ scene.
- Không tự tải asset từ URL không nằm trong manifest.

Build CI phải fail với asset thiếu; fallback chỉ bảo vệ runtime khi asset bị hỏng sau deploy.

## 13. Asset QA checklist

- [ ] Có source/master file.
- [ ] Có license hoặc ghi rõ tạo nội bộ.
- [ ] Có asset ID ổn định.
- [ ] Có manifest.
- [ ] Frame cùng canvas size.
- [ ] Anchor/pivot khớp debug grid.
- [ ] Không sai perspective/light/scale.
- [ ] Không texture bleeding ở atlas.
- [ ] Atlas không vượt 2048x2048/mobile budget.
- [ ] Preview loop không giật.
- [ ] Missing-frame validator pass.
- [ ] Runtime mapping pass.
- [ ] Mobile FPS/memory pass.

## 14. Animation Definition of Done

Một animation MVP chỉ hoàn thành khi có đủ:

```text
source frame
→ naming validator
→ manifest
→ atlas
→ preview
→ renderer state mapping
→ mobile QA
→ license/asset metadata
```

Không đánh dấu feature animation hoàn thành chỉ vì đã có một ảnh tĩnh hoặc một `AnimatedSprite` chạy được trong desktop.
